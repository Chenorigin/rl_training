"""Instrument the existing MuJoCo deployment without changing its controller."""
from contextlib import nullcontext
from pathlib import Path
from types import SimpleNamespace
import hashlib
import json
import resource
import subprocess
import sys
import time

import mujoco
import numpy as np
from PIL import Image, ImageDraw, ImageFont

SPEC = json.loads(Path(__file__).with_name('spec.json').read_text())
ROOT = Path(SPEC['root'])
sys.path.insert(0, str(ROOT / 'deploy/deploy_mujoco'))
import deploy_mujoco as dm
from quiet_landing_metrics import QuietMujocoMetrics

label, case = sys.argv[1:3]
definition = SPEC['cases'][case]
identity = SPEC['checkpoints'][label]
checkpoint = Path(identity['frozen_copy'])
assert hashlib.sha256(checkpoint.read_bytes()).hexdigest() == identity['sha256']
for filename, expected in SPEC['source_sha256'].items():
    assert hashlib.sha256(Path(filename).read_bytes()).hexdigest() == expected, filename
OUT = Path(SPEC['output']) / f'{label}_{case}'
OUT.mkdir(exist_ok=False)
video = OUT / 'live.mp4'
begin, end = definition['video_window_s']
full, observed, obs_times = [], [], []
state = {'step1': 0, 'step2': 0, 'frames': 0, 'command': np.zeros(3)}
titles = {'v1': '原版 v1 · 257100', 'cpu': 'CPU 驻足停车修复 · 8000步', 'v2': '步态调整 v2 · 2400'}
case_names = {'idle': '零命令驻足', 'move_stop': '前进后停车', 'ascent': '独立上楼 · 20阶',
              'descent': '独立下楼 · 20阶', 'combined': '连续上楼/下楼 · 各6阶'}
font = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 18)
small = ImageFont.truetype('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc', 15)
original_step1, original_step2 = mujoco.mj_step1, mujoco.mj_step2


def step1(model, data):
    state['step1'] += 1
    return original_step1(model, data)


def step2(model, data):
    state['step2'] += 1
    return original_step2(model, data)


original_init = dm.M20Contract.__init__
original_observe = dm.M20Contract.observe


def contract_init(self, *args, **kwargs):
    original_init(self, *args, **kwargs)
    state['contract'] = self


def observe(self, data, command, previous_action):
    value = original_observe(self, data, command, previous_action)
    observed.append(value.copy())
    obs_times.append(float(data.time))
    return value


dm.M20Contract.__init__ = contract_init
dm.M20Contract.observe = observe
mujoco.mj_step1, mujoco.mj_step2 = step1, step2


def model_fingerprint(model):
    names = ('body_parentid', 'body_mass', 'body_inertia', 'body_ipos', 'body_iquat',
             'jnt_type', 'jnt_qposadr', 'jnt_dofadr', 'jnt_axis', 'jnt_pos', 'jnt_range',
             'dof_damping', 'dof_armature', 'geom_type', 'geom_size', 'geom_pos', 'geom_quat',
             'geom_bodyid', 'geom_contype', 'geom_conaffinity', 'geom_friction', 'geom_solref',
             'geom_solimp', 'geom_condim', 'actuator_trnid', 'actuator_gear',
             'actuator_ctrlrange', 'mesh_vert', 'mesh_face')
    digest = hashlib.sha256()
    for name in names:
        value = np.asarray(getattr(model, name))
        digest.update(name.encode()); digest.update(str(value.shape).encode()); digest.update(value.tobytes())
    digest.update(str(model.opt.timestep).encode())
    return digest.hexdigest()


class Viewer:
    def __init__(self, model, data):
        self.cam = SimpleNamespace()
        self.model, self.data = model, data
        self.visual = mujoco.MjData(model)
        self.renderer = mujoco.Renderer(model, height=360, width=640)
        self.camera = mujoco.MjvCamera()
        self.camera.type = mujoco.mjtCamera.mjCAMERA_FREE
        self.camera.distance = 3.6 if case in {'idle', 'move_stop'} else 3.1
        self.camera.azimuth = 125 if case in {'idle', 'move_stop'} else 110
        self.camera.elevation = -26
        self.calls = 0
        self.anchor = self.reference = self.reference_yaw = None
        self.motion_yaw = None
        self.max_displacement = 0.
        self.pipe = subprocess.Popen([
            'ffmpeg', '-hide_banner', '-loglevel', 'error', '-n', '-f', 'rawvideo',
            '-pix_fmt', 'rgb24', '-s', '640x456', '-r', '25', '-i', '-', '-an',
            '-c:v', 'libx264', '-threads', '1', '-crf', '20', '-pix_fmt', 'yuv420p', str(video)
        ], stdin=subprocess.PIPE)
        state['compiled_model_sha256'] = model_fingerprint(model)

    def lock(self): return nullcontext()
    def is_running(self): return True

    def sync(self):
        data = self.data
        # Measurement/rendering has its own data object. It never advances physics.
        self.visual.qpos[:] = data.qpos
        self.visual.qvel[:] = data.qvel
        mujoco.mj_forward(self.model, self.visual)
        contract = state['contract']; base = contract.base_id
        position = self.visual.xpos[base].copy()
        quat = self.visual.xquat[base].copy()
        w, x, y, z = quat
        yaw = np.arctan2(2*(w*z+x*y), 1-2*(y*y+z*z))
        velocity = np.zeros(6)
        mujoco.mj_objectVelocity(self.model, self.visual, mujoco.mjtObj.mjOBJ_BODY,
                                base, velocity, 0)
        full.append((float(data.time), data.qpos.copy(), data.qvel.copy(), position, quat,
                     self.visual.xpos[contract.wheel_body_ids].copy(), velocity.copy(),
                     self.visual.xmat[base].reshape(3, 3)[2, 2],
                     self.visual.qvel[contract.qvel_ids].copy()))
        t = float(data.time)
        reference_time = 10. if case == 'idle' else (14.02 if case == 'move_stop' else 8.)
        if self.reference is None and t >= reference_time-1e-7:
            self.reference = position[:2].copy(); self.reference_yaw = yaw
            if case in {'idle', 'move_stop'}: self.anchor = position.copy()
        if self.reference is not None:
            self.max_displacement = max(self.max_displacement, float(np.linalg.norm(position[:2]-self.reference)))
        self.calls += 1
        if self.calls % 2 or t < begin-1e-7 or t >= end-1e-7: return
        self.camera.lookat[:] = self.anchor if self.anchor is not None else position
        self.renderer.update_scene(self.visual, camera=self.camera)
        self.renderer.scene.flags[mujoco.mjtRndFlag.mjRND_SHADOW] = False
        self.renderer.scene.flags[mujoco.mjtRndFlag.mjRND_REFLECTION] = False
        scene = self.renderer.scene
        ground = contract.ground_height(self.visual, float(position[0]), float(position[1]))
        if case in {'idle', 'move_stop'}:
            for axis in range(2):
                for v in np.arange(-5., 9.01, .5):
                    if scene.ngeom >= scene.maxgeom: break
                    start, stop = np.array([-5., v, .002]), np.array([9., v, .002])
                    if axis: start, stop = start[[1, 0, 2]], stop[[1, 0, 2]]
                    geom = scene.geoms[scene.ngeom]
                    mujoco.mjv_initGeom(geom, mujoco.mjtGeom.mjGEOM_LINE, np.ones(3),
                                       np.zeros(3), np.eye(3).ravel(), np.array([.65,.69,.73,1],np.float32))
                    mujoco.mjv_connector(geom, mujoco.mjtGeom.mjGEOM_LINE, 1., start, stop)
                    scene.ngeom += 1
        canvas = Image.new('RGB', (640,456), '#f8fafc')
        canvas.paste(Image.fromarray(self.renderer.render()), (0,40))
        draw = ImageDraw.Draw(canvas)
        draw.text((10,8), titles[label]+' | '+case_names[case],font=font,fill='#0f172a')
        cmd = state['command']
        phase = '驻足' if case == 'idle' else ('松W停车' if case == 'move_stop' and t>=14 else '前进' if np.linalg.norm(cmd) else '准备')
        draw.text((10,402), f't={t:.2f}s  {phase}  指令=({cmd[0]:.2f}, {cmd[1]:.2f}, {cmd[2]:.2f})',font=small,fill='#0f172a')
        relative = np.rad2deg(np.arctan2(np.sin(yaw-(self.reference_yaw or 0)),np.cos(yaw-(self.reference_yaw or 0))))
        speed = np.linalg.norm(velocity[3:5])*1000
        if case in {'idle','move_stop'} and self.reference is not None:
            text=f'最大位移={self.max_displacement*100:.2f}cm  速度={speed:.2f}mm/s  偏航={relative:.2f}°'
        else:
            text=f'x={position[0]:.2f}m  y={position[1]:.2f}m  速度={speed:.1f}mm/s  偏航={relative:.2f}°'
        draw.text((10,427),text,font=small,fill='#0f172a')
        if t>=6 and (position[2]<ground+.22 or full[-1][7]<.35):
            draw.text((465,56),'检测到跌倒',font=font,fill='#dc2626')
        self.pipe.stdin.write(np.asarray(canvas).tobytes()); state['frames'] += 1
        if state['frames'] in {1,200,600}: canvas.save(OUT/f'frame_{state["frames"]}.jpg')

    def close(self):
        if state['frames']==0:
            # Preserve early failure visibly; never turn it into a missing case.
            self.camera.lookat[:]=self.visual.xpos[state['contract'].base_id]
            self.renderer.update_scene(self.visual,camera=self.camera)
            canvas=Image.new('RGB',(640,456),'#f8fafc')
            canvas.paste(Image.fromarray(self.renderer.render()),(0,40))
            draw=ImageDraw.Draw(canvas)
            draw.text((10,8),titles[label]+' | '+case_names[case],font=font,fill='#0f172a')
            draw.text((10,405),'在预定视频窗口前终止；本例没有完成',font=font,fill='#dc2626')
            draw.text((10,430),f'实际终止 t={self.data.time:.2f}s',font=small,fill='#dc2626')
            self.pipe.stdin.write(np.asarray(canvas).tobytes())
            canvas.save(OUT/'early_failure.jpg')
            state['frames']=1; state['early_termination_before_video_window']=True
        self.pipe.stdin.close()
        code=self.pipe.wait(timeout=30)
        self.renderer.close()
        if code: raise RuntimeError(f'Video encoder exited {code}')


def launch(model,data,key_callback=None):
    state['data']=data
    return Viewer(model,data),[]


class Keys:
    _window_keys=None
    def __init__(self): self.z=self.c=False
    def on_keycode(self,*args): pass
    def take_events(self):
        t=state['data'].time
        if not self.z: self.z=True; return ['z']
        if t>=6 and not self.c: self.c=True; return ['c']
        return []
    def velocity_command(self):
        t=state['data'].time; command=np.zeros(3,dtype=np.float32)
        for at, value in definition['command_schedule']:
            if t>=at: command=np.asarray(value,dtype=np.float32)
        state['command']=command
        return command.copy()
    def clear_motion(self): pass
    def close(self): pass


class Terminal:
    def __init__(self,*args): pass
    def start(self): return False
    def poll(self): pass
    def close(self): pass


QuietMujocoMetrics.draw=lambda *args:None
dm.launch_viewer=launch; dm.draw_height_scan=lambda *args:None
dm.TeleopKeyboard=Keys; dm.TerminalInput=Terminal; dm.time.sleep=lambda *args:None
args=SimpleNamespace(checkpoint=checkpoint,model=Path(SPEC['robot_xml']),terrain=None,
    terrain_xml=Path(SPEC['terrain_xml'][definition['terrain']]),quiet_landing=True,
    live_plot=False,output=OUT/'control.npz',steps=round(definition['duration_s']/dm.POLICY_DT),
    print_every=600,stop_on_fall=True)
started=time.perf_counter(); result=dm.interactive_rollout(args)
assert result['steps_executed']==len(full)
assert state['step1']==state['step2']==len(full)*4
assert result['steps_executed']==args.steps or result['fell_in_policy']
assert state['frames']>0
names=('time','qpos','qvel','position','quaternion','wheels_world','world_velocity','Rzz','joint_velocity')
arrays={name:np.asarray([r[i] for r in full]) for i,name in enumerate(names)}
arrays['policy_time']=np.asarray(obs_times); arrays['policy_observation']=np.asarray(observed)
assert all(np.isfinite(v).all() for v in arrays.values())
np.savez_compressed(OUT/'state.npz',**arrays)
receipt={'label':label,'case':case,'checkpoint':identity,'source_sha256':SPEC['source_sha256'],
         'compiled_model_sha256':state['compiled_model_sha256'],'deployment_entry':SPEC['deployment_entry'],
         'policy_dt':dm.POLICY_DT,'physics_dt':dm.PHYSICS_DT,'deterministic_actor':True,
         'course_correction':False,'command_schedule':definition['command_schedule'],
         'mj_step1_calls':state['step1'],'mj_step2_calls':state['step2'],'frames':state['frames'],
         'fps':25,'live_capture':True,'clip_start_s':begin,'clip_end_s':end,
         'early_termination_before_video_window':state.get('early_termination_before_video_window',False),
         'video_sha256':hashlib.sha256(video.read_bytes()).hexdigest(),'result':result,
         'wall_seconds':time.perf_counter()-started,'peak_RSS_MiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss/1024,
         'substitutions':['keyboard input follows frozen schedule','headless live video viewer','wall pacing disabled'],
         'instrumentation':['original observe return copied','step1/step2 invocation counters','separate MjData forwarded for measurements/render only']}
(OUT/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2))
print('CASE_COMPLETE',label,case,'frames',state['frames'],'fell',result['fell_in_policy'],
      'rss_MiB',receipt['peak_RSS_MiB'],'wall_s',receipt['wall_seconds'],flush=True)
