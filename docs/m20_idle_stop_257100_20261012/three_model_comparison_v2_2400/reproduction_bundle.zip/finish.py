"""Verify and present the already recorded comparison; no training or physics run."""
from pathlib import Path
from types import SimpleNamespace
import csv
import hashlib
import json
import subprocess
import sys
import zipfile
import numpy as np

WORK = Path(__file__).resolve().parent
SPEC = json.loads((WORK/'spec.json').read_text())
OUT = Path(SPEC['output'])
ROOT = Path(SPEC['root'])
LABELS = ['v1', 'cpu', 'v2']
NAMES = ['原版 v1 / 257100', 'CPU 驻足停车 / 8000步', '步态调整 v2 / 2400']
COLORS = ['#0072B2', '#D55E00', '#009E73']
CASES = ['idle', 'move_stop', 'combined', 'ascent', 'descent']
TITLES = ['驻足', '前进后停车', '连续上下楼（各6阶）', '独立上楼（20阶）', '独立下楼（20阶）']
FILENAMES = ['idle_compare.mp4', 'move_stop_compare.mp4', 'combined_stairs_compare.mp4',
             'ascent_compare.mp4', 'descent_compare.mp4']
METRICS = json.loads((OUT/'metrics.json').read_text())['metrics']


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()


def probe(path):
    r = subprocess.run(['ffprobe','-v','error','-select_streams','v:0',
        '-show_entries','stream=width,height,r_frame_rate,nb_frames,duration',
        '-of','json',str(path)], capture_output=True, text=True, check=True)
    return json.loads(r.stdout)['streams'][0]


def data(label, case):
    with np.load(OUT/f'{label}_{case}/state.npz') as f:
        return {k:f[k].copy() for k in f.files}


def angles(q):
    w,x,y,z=q.T
    return np.rad2deg(np.column_stack((
        np.arctan2(2*(w*x+y*z),1-2*(x*x+y*y)),
        np.arcsin(np.clip(2*(w*y-z*x),-1,1)),
        np.unwrap(np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))))))


def verify():
    import torch
    from tensordict import TensorDict
    sys.path.insert(0,str(ROOT/'deploy/deploy_mujoco'))
    import deploy_mujoco as dm
    torch.set_num_threads(1)
    for path, expected in SPEC['source_sha256'].items(): assert sha(path)==expected,path
    actors={};states={};result={'source_sha256_verified':True,'models':{},'cases':{},'ascent_termination':{}}
    for label in LABELS:
        identity=SPEC['checkpoints'][label]
        assert sha(identity['path'])==sha(identity['frozen_copy'])==identity['sha256']
        actors[label]=dm.load_actor(Path(identity['frozen_copy']))
        saved=torch.load(identity['frozen_copy'],map_location='cpu',weights_only=True)
        states[label]=saved['actor_state_dict']
        std=states[label]['distribution.log_std_param'].exp().numpy()
        result['models'][label]={'iteration_metadata':saved.get('iter'),
            'mean_std':float(std.mean()),'minimum_std':float(std.min()),'maximum_std':float(std.max()),
            'checkpoint_sha256':identity['sha256'],
            'training_metadata':saved.get('idle_stop_calibration',saved.get('gait_corrections_v2'))}
    for label in ['cpu','v2']:
        changed=[]
        for key in states['v1']:
            if not torch.equal(states['v1'][key],states[label][key]): changed.append(key)
        assert all(k.startswith(('mlp.4.','mlp.6.')) for k in changed),changed
        assert changed
        result['models'][label]['actor_tensors_different_from_v1']=changed
        result['models'][label]['front_and_distribution_bitwise_equal_to_v1']=True
    for case in CASES:
        baseline=data('v1',case);checks={}
        for label in LABELS:
            folder=OUT/f'{label}_{case}';d=data(label,case)
            r=json.loads((folder/'receipt.json').read_text())
            p=probe(folder/'live.mp4')
            assert p['width']==640 and p['height']==456 and p['r_frame_rate']=='25/1'
            assert int(p['nb_frames'])==r['frames']
            assert sha(folder/'live.mp4')==r['video_sha256']
            before=d['time']<=6.+1e-7
            assert np.array_equal(d['qpos'][before],baseline['qpos'][baseline['time']<=6.+1e-7])
            assert np.array_equal(d['qvel'][before],baseline['qvel'][baseline['time']<=6.+1e-7])
            with np.load(folder/'control.npz') as f: c={k:f[k].copy() for k in f.files}
            policy=np.flatnonzero(c['mode']=='policy')
            assert np.array_equal(c['time'][policy],d['policy_time'])
            use=d['policy_time']>=d['policy_time'][0]+.3+1e-7
            obs=torch.from_numpy(d['policy_observation'][use]).float()
            with torch.inference_mode():
                predicted=actors[label](TensorDict({'policy':obs},batch_size=[len(obs)])).numpy().clip(-100,100)
            measured=c['action'][policy[use]]
            batch_error=float(np.max(abs(predicted-measured)))
            # Native deployment infers one sample at a time. Batched GEMM can
            # differ in float32 rounding; use native-shaped inference if needed.
            error=batch_error
            if batch_error>=2e-5:
                with torch.inference_mode():
                    predicted=np.concatenate([actors[label](TensorDict({'policy':v[None]},batch_size=[1])).numpy() for v in obs]).clip(-100,100)
                error=float(np.max(abs(predicted-measured)))
                assert error==0.,(label,case,error)
            assert error<2e-5,(label,case,error)
            checks[label]={'video_probe':p,'live_video_sha256_verified':True,
                'pre_policy_qpos_qvel_bitwise_equal_to_v1':True,
                'actual_actor_action_match_max_abs_error':error,
                'batched_float32_inference_max_abs_error':batch_error,
                'native_single_sample_fallback_checked':batch_error>=2e-5,
                'actual_actor_action_samples_checked':len(obs)}
        result['cases'][case]=checks
    for label in LABELS:
        d=data(label,'ascent');s=METRICS[label]['ascent']['sections'][0]
        after=d['time']>=s['exit_time_s']
        front=np.flatnonzero(after & (d['wheels_world'][:,:,0].max(axis=1)>16.25))
        side=np.flatnonzero(after & (abs(d['wheels_world'][:,:,1]).max(axis=1)>2.))
        result['ascent_termination'][label]={
            'stairs_cleared_time_s':s['exit_time_s'],
            'first_wheel_center_beyond_front_after_exit_s':float(d['time'][front[0]]) if len(front) else None,
            'first_wheel_center_beyond_side_after_exit_s':float(d['time'][side[0]]) if len(side) else None,
            'termination_time_s':float(d['time'][-1]),'final_measured_position_m':d['position'][-1].tolist(),
            'final_measured_Rzz':float(d['Rzz'][-1]),
            'final_wheel_centers_xy_m':d['wheels_world'][-1,:,:2].tolist(),
            'note':'Footprint boundary crossing measured separately from native fall/low-clearance termination; not a claim about failure to climb.'}
    (OUT/'verification.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('VERIFIED all 15 original videos, model/source identities, initial states, and actual actor actions',flush=True)


def assemble():
    font='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
    meta=[]
    for case, title, filename in zip(CASES,TITLES,FILENAMES):
        duration=np.diff(SPEC['cases'][case]['video_window_s'])[0]
        cmd=['ffmpeg','-hide_banner','-loglevel','error','-n','-filter_complex_threads','1']
        filters=[];padding={}
        for i,label in enumerate(LABELS):
            cmd+=['-threads','1','-i',str(OUT/f'{label}_{case}/live.mp4')]
            receipt=json.loads((OUT/f'{label}_{case}/receipt.json').read_text())
            actual=receipt['frames']/25
            f=f'[{i}:v]setpts=PTS-STARTPTS,tpad=stop_mode=clone:stop_duration={duration},trim=duration={duration}'
            if actual<duration:
                textfile=WORK/f'{label}_{case}_terminated.txt'
                textfile.write_text('原部署已因跌倒/机身过低终止 · 此后定格')
                f+=f",drawtext=fontfile={font}:textfile={textfile}:fontsize=22:fontcolor=white:box=1:boxcolor=red@0.85:boxborderw=7:x=12:y=55:enable='gte(t,{actual})'"
                padding[label]={'original_video_duration_s':actual,'padded_frozen_seconds':float(duration-actual),'termination_annotation':True}
            filters.append(f+f'[p{i}]')
        filters.append('[p0][p1][p2]hstack=inputs=3[v]')
        cmd+=['-filter_complex',';'.join(filters),'-map','[v]','-an','-c:v','libx264',
              '-threads','1','-crf','20','-pix_fmt','yuv420p','-r','25','-movflags','+faststart',str(OUT/filename)]
        subprocess.run(cmd,check=True,timeout=240)
        p=probe(OUT/filename)
        assert p['width']==1920 and p['height']==456 and int(p['nb_frames'])==duration*25
        meta.append({'case':case,'title':title,'file':filename,'sha256':sha(OUT/filename),'probe':p,
                     'source_clip_start_s':SPEC['cases'][case]['video_window_s'][0],
                     'side_by_side_order':LABELS,'playback_speed':1.,'early_termination_padding':padding})
        print('ASSEMBLED',filename,p['duration'],'seconds',flush=True)
    concat=WORK/'concat.txt'
    concat.write_text(''.join(f"file '{OUT/name}'\n" for name in FILENAMES))
    full=OUT/'m20_v1_cpu_v2_2400_mujoco_compare.mp4'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-n','-f','concat','-safe','0','-i',
        str(concat),'-c','copy','-movflags','+faststart',str(full)],check=True,timeout=60)
    p=probe(full)
    assert int(p['nb_frames'])==sum(int(m['probe']['nb_frames']) for m in meta)
    result={'clips':meta,'full_video':{'file':full.name,'sha256':sha(full),'probe':p},
        'segment_order':CASES,'no_time_stretch':True,'original_live_capture_preserved':True}
    (OUT/'video_manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
    print('ASSEMBLED full comparison',p['duration'],'seconds',flush=True)


def plots():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font_manager.fontManager.addfont('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
    plt.rcParams.update({'font.family':'Noto Sans CJK JP','font.size':10,'axes.unicode_minus':False,
                         'axes.spines.top':False,'axes.spines.right':False})
    fig,axs=plt.subplots(2,2,figsize=(13,8),constrained_layout=True)
    for label,name,color in zip(LABELS,NAMES,COLORS):
        for case,start,ax in [('idle',10.,axs[0,0]),('move_stop',14.02,axs[0,1])]:
            d=data(label,case);ids=np.flatnonzero(d['time']>=start-1e-7);i=ids[0]
            drift=np.linalg.norm(d['position'][ids,:2]-d['position'][i,:2],axis=1)*100
            ax.plot(d['time'][ids]-start,drift,color=color,label=name)
        d=data(label,'move_stop');ids=d['time']>=14.02-1e-7
        speed=np.linalg.norm(d['world_velocity'][ids,3:5],axis=1)*1000
        axs[1,0].semilogy(d['time'][ids]-14.02,speed,color=color,label=name)
        wheel=np.sqrt(np.mean(d['joint_velocity'][ids,12:]**2,axis=1))
        axs[1,1].plot(d['time'][ids]-14.02,wheel,color=color,label=name)
    for ax,limit,title in [(axs[0,0],5,'驻足最大轨迹偏移（26秒）'),(axs[0,1],10,'松W后轨迹偏移（22秒）')]:
        ax.axhline(limit,color='#666',ls='--',label=f'{limit} cm 判据')
        ax.set(title=title,ylabel='相对参考位置的距离 (cm)',xlabel='距参考时刻 (s)')
        ax.legend(fontsize=8,loc='upper left');ax.grid(alpha=.2)
        inset=ax.inset_axes([.53,.16,.44,.46]);inset.set_facecolor('#f8fafc')
        case='idle' if ax==axs[0,0] else 'move_stop';start=10. if case=='idle' else 14.02
        for label,color in zip(LABELS[1:],COLORS[1:]):
            d=data(label,case);ids=np.flatnonzero(d['time']>=start-1e-7);i=ids[0]
            inset.plot(d['time'][ids]-start,np.linalg.norm(d['position'][ids,:2]-d['position'][i,:2],axis=1)*100,color=color)
        inset.set_title('CPU 与 v2 放大',fontsize=8);inset.tick_params(labelsize=7);inset.grid(alpha=.15)
    axs[1,0].axhline(5.,color='#666',ls='--',label='5 mm/s 判据')
    axs[1,0].set(title='停车后机身水平瞬时速度',ylabel='速度 (mm/s，对数轴)',xlabel='松W后 (s)',xlim=(0,22))
    axs[1,1].set(title='停车后四轮实测关节速度 RMS',ylabel='轮关节速度 (rad/s)',xlabel='松W后 (s)',xlim=(0,22))
    for ax in axs[1]: ax.legend(fontsize=8);ax.grid(alpha=.2)
    fig.suptitle('同一原生部署控制器 · v1 / CPU 驻足停车 / v2_2400',fontsize=15)
    for suffix in ['png','pdf']:fig.savefig(OUT/f'flat_motion_comparison.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    fig,axs=plt.subplots(3,2,figsize=(13,10),sharex=True,constrained_layout=True)
    for row,(label,name,color) in enumerate(zip(LABELS,NAMES,COLORS)):
        for col,case in enumerate(['ascent','descent']):
            ax=axs[row,col];d=data(label,case);s=METRICS[label][case]['sections'][0]
            yaw=angles(d['quaternion'])[:,2];i=np.flatnonzero(d['time']>=s['start_heading_reference_time_s']-1e-7)[0]
            mask=d['time']>=8.;error=yaw-yaw[i]
            ax.plot(d['time'][mask],error[mask],color=color,label=name)
            ax.axhspan(-5,5,color='#009E73',alpha=.08)
            ax.axhline(5,color='#777',ls='--',lw=.8);ax.axhline(-5,color='#777',ls='--',lw=.8)
            ax.axvspan(s['entry_time_s'],s['exit_time_s'],color='#888',alpha=.12,label='楼梯过程')
            ax.axvspan(s['exit_time_s'],s['exit_time_s']+2,color='#E69F00',alpha=.14,label='楼梯后2秒')
            if METRICS[label][case]['fell']:
                ax.scatter(d['time'][-1],error[-1],marker='x',color='#b91c1c',s=45)
                ax.annotate('原部署终止',(d['time'][-1],error[-1]),xytext=(-6,10),textcoords='offset points',ha='right',fontsize=8)
            ax.set(ylabel='相对出发朝向的偏航 (°)',title=f'{name} · {"上楼" if col==0 else "下楼"}')
            ax.text(.98,.03,f"后窗峰值 {s['after_max_error_deg']:.2f}° / 过程峰值 {s['during_max_error_deg']:.2f}°",transform=ax.transAxes,ha='right',fontsize=9)
            ax.grid(alpha=.2);ax.legend(loc='upper left',fontsize=7)
    for ax in axs[-1]:ax.set(xlabel='物理时间 (s)',xlim=(8,36))
    fig.suptitle('独立20阶楼梯：5°前后判据与过程峰值分开报告',fontsize=15)
    for suffix in ['png','pdf']:fig.savefig(OUT/f'stairs_heading_comparison.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(13,4.5),constrained_layout=True)
    for label,name,color in zip(LABELS,NAMES,COLORS):
        d=data(label,'combined');mask=(d['time']>=8)&(d['time']<=23)
        s=METRICS[label]['combined']['sections'][0]
        yaw=angles(d['quaternion'])[:,2];i=np.flatnonzero(d['time']>=s['start_heading_reference_time_s']-1e-7)[0]
        axs[0].plot(d['time'][mask],yaw[mask]-yaw[i],color=color,label=name)
        axs[1].plot(d['position'][mask,0],d['position'][mask,1],color=color,label=name)
    for start,end,title in [(1,2.8,'上楼'),(4.8,6.6,'下楼')]:
        axs[1].axvspan(start,end,color='#888',alpha=.15)
        axs[1].text((start+end)/2,.45,title,ha='center')
    axs[0].axhspan(-5,5,color='#009E73',alpha=.08)
    axs[0].axhline(5,color='#777',ls='--',lw=.8);axs[0].axhline(-5,color='#777',ls='--',lw=.8)
    axs[0].set(title='连续上下楼：朝向偏差随物理时间',xlabel='物理时间 (s)',ylabel='相对出发朝向 (°)')
    axs[1].set(title='连续上下楼：平面轨迹',xlabel='世界 X (m)',ylabel='世界 Y (m)',ylim=(-.6,.5))
    for ax in axs:ax.grid(alpha=.2);ax.legend(fontsize=8)
    for suffix in ['png','pdf']:fig.savefig(OUT/f'combined_stairs_comparison.{suffix}',dpi=180,bbox_inches='tight')
    plt.close(fig)
    print('PLOTTED six standalone PNG/PDF artifacts',flush=True)


def tables():
    rows=[]
    for label in LABELS:
        for case in CASES:
            d=METRICS[label][case]
            common={'model':label,'scenario':case,'fell_or_low_clearance':d['fell'],'duration_s':d['duration_s']}
            if case in ['idle','move_stop']:
                rows.append({**common,'maximum_displacement_cm':100*d['max_displacement_m'],
                    'last10_path_speed_mm_s':1000*d['last10_path_speed_m_s'],
                    'maximum_yaw_deg':d['max_yaw_excursion_deg'],'settling_time_s':d['settling_time_s'],
                    'prestop_forward_m':d.get('prestop_forward_progress_m'),
                    'acceptance_pass':d.get('stop_acceptance_pass',d['static_stop_constraints_pass'])})
            else:
                for s in d['sections']:
                    rows.append({**common,'section':s['name'],'stairs_completed':s['completed'],
                        'before_max_deg':s['before_max_error_deg'],'after_max_deg':s['after_max_error_deg'],
                        'during_max_deg':s['during_max_error_deg'],'before_to_after_signed_mean_delta_deg':s['before_to_after_mean_delta_deg'],
                        'acceptance_pass':s['heading_pass'],'landing_performance_eligible':d['landing_performance_eligible'],
                        'touchdown_40ms_mean_peak_force_N':d.get('touchdown_40ms_mean_peak_force_N') if d['landing_performance_eligible'] else None,
                        'touchdown_cumulative_specific_energy_per_forward_m':d.get('touchdown_cumulative_specific_energy_per_forward_m') if d['landing_performance_eligible'] else None})
    fields=list(dict.fromkeys(k for row in rows for k in row))
    with (OUT/'comparison.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fields);writer.writeheader();writer.writerows(rows)


if __name__=='__main__':
    for job in sys.argv[1:]:
        {'verify':verify,'assemble':assemble,'plots':plots,'tables':tables}[job]()
