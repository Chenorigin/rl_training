from pathlib import Path
import json
import os
import subprocess
import sys
import time

work=Path(__file__).resolve().parent
spec=json.loads((work/'spec.json').read_text())
env=os.environ.copy()
env.update({'CUDA_VISIBLE_DEVICES':'','MUJOCO_GL':'osmesa','OMP_NUM_THREADS':'1',
            'MKL_NUM_THREADS':'1','OPENBLAS_NUM_THREADS':'1','LP_NUM_THREADS':'1'})
timeout_count=0; receipts=[]
for case in ['idle','move_stop','combined','ascent','descent']:
    for label in ['v1','cpu','v2']:
        folder=Path(spec['output'])/f'{label}_{case}'
        if (folder/'receipt.json').is_file():
            receipts.append(json.loads((folder/'receipt.json').read_text()))
            print('ALREADY_COMPLETED',label,case,flush=True)
            continue
        log=Path(spec['output'])/f'{label}_{case}.log'
        print('START',label,case,flush=True)
        started=time.perf_counter()
        with log.open('x') as stream:
            try:
                completed=subprocess.run([sys.executable,str(work/'record.py'),label,case],
                    cwd=spec['root'],env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=240)
            except subprocess.TimeoutExpired:
                timeout_count+=1
                print('TIMEOUT',label,case,flush=True)
                if timeout_count>=2: raise RuntimeError('Two consecutive recording timeouts; stopping')
                continue
        timeout_count=0
        if completed.returncode:
            print('FAILED_LOG',log,flush=True)
            print(log.read_text()[-3500:],flush=True)
            raise RuntimeError(f'{label}/{case} infrastructure failed with {completed.returncode}')
        receipt=json.loads((folder/'receipt.json').read_text())
        receipts.append(receipt)
        (Path(spec['output'])/'progress.json').write_text(json.dumps(receipts,ensure_ascii=False,indent=2))
        print('COMPLETE',label,case,'wall_s',round(time.perf_counter()-started,1),
              'fell',receipt['result']['fell_in_policy'],'frames',receipt['frames'],flush=True)
assert len(receipts)==15
print('ALL_COMPLETED',len(receipts),flush=True)
