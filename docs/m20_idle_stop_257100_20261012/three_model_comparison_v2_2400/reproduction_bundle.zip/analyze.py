"""Fixed-window comparison of three actual deployment runs."""
from pathlib import Path
import hashlib
import json
import sys
import numpy as np

WORK=Path(__file__).resolve().parent
SPEC=json.loads((WORK/'spec.json').read_text())
OUT=Path(SPEC['output'])
A=SPEC['criteria']
RADIUS=.09


def angles(quaternion):
    w,x,y,z=quaternion.T
    return np.rad2deg(np.column_stack((
        np.arctan2(2*(w*x+y*z),1-2*(x*x+y*y)),
        np.arcsin(np.clip(2*(w*y-z*x),-1,1)),
        np.unwrap(np.arctan2(2*(w*z+x*y),1-2*(y*y+z*z))))))


def settled_time(t,velocity,start):
    valid=(np.linalg.norm(velocity[:,3:5],axis=1)<=A['settling_speed_m_s'])
    valid &= abs(velocity[:,2])<=A['settling_abs_yaw_rate_rad_s']
    count=0
    for i in np.flatnonzero(t>=start-1e-7):
        count=count+1 if valid[i] else 0
        if count and t[i]-t[i-count+1]>=A['settling_hold_s']-1e-7:
            return float(t[i-count+1]-start)
    return None


def window_stats(t,p,yaw,velocity,start):
    ids=np.flatnonzero(t>=start-1e-7)
    if not len(ids): return {'window_available':False}
    i=ids[0];last=np.flatnonzero(t>=t[-1]-10-1e-7)[0]
    displacement=np.linalg.norm(p[i:,:2]-p[i,:2],axis=1)
    path=np.linalg.norm(np.diff(p[i:,:2],axis=0),axis=1).sum()
    duration=float(t[-1]-t[last])
    return {'window_available':True,'reference_time_s':float(t[i]),
            'max_displacement_m':float(displacement.max()),'net_displacement_m':float(displacement[-1]),
            'path_length_m':float(path),'last10_path_speed_m_s':float(np.linalg.norm(np.diff(p[last:,:2],axis=0),axis=1).sum()/duration),
            'max_yaw_excursion_deg':float(abs(yaw[i:]-yaw[i]).max()),
            'final_yaw_delta_deg':float(yaw[-1]-yaw[i]),
            'last10_mean_abs_yaw_rate_rad_s':float(abs(velocity[last:,2]).mean()),
            'settling_time_s':settled_time(t,velocity,float(t[i]))}


def section_stats(t,p,wheels,yaw,section,moving_time,fell):
    entry=np.flatnonzero((t>=moving_time-1e-7)&(wheels[:,:,0].max(axis=1)+RADIUS>=section['start_x']))
    if not len(entry):
        return {'name':section['name'],'entered':False,'completed':False,'heading_pass':False,'reason':'never entered stairs'}
    i=int(entry[0]); reference=int(np.flatnonzero(t>=moving_time-1e-7)[0])
    error=yaw-yaw[reference]
    exit_ids=np.flatnonzero((np.arange(len(t))>=i)&(wheels[:,:,0].min(axis=1)-RADIUS>=section['end_x']))
    j=int(exit_ids[0]) if len(exit_ids) else len(t)-1
    before=(t>=t[i]-A['before_stairs_window_s']-1e-7)&(t<t[i]-1e-7)
    during=(np.arange(len(t))>=i)&(np.arange(len(t))<=j)
    inside=bool((abs(wheels[during,:,1])<=A['stairs_width_m']/2).all())
    result={'name':section['name'],'entered':True,'completed':bool(len(exit_ids)),
            'entry_time_s':float(t[i]),'exit_time_s':float(t[j]) if len(exit_ids) else None,
            'start_heading_reference_time_s':float(t[reference]),'reference_world_yaw_deg':float(yaw[reference]),
            'before_max_error_deg':float(abs(error[before]).max()) if before.any() else None,
            'before_mean_error_deg':float(error[before].mean()) if before.any() else None,
            'during_max_error_deg':float(abs(error[during]).max()),
            'during_mean_abs_error_deg':float(abs(error[during]).mean()),
            'during_fraction_outside_5deg':float((abs(error[during])>A['heading_limit_deg']).mean()),
            'max_abs_world_yaw_deg':float(abs(yaw[during]).max()),
            'maximum_abs_lateral_m':float(abs(p[during,1]).max()),'inside_course_during':inside,
            'after_window_available':False,'heading_pass':False,
            'after_max_error_deg':None,'before_to_after_mean_delta_deg':None}
    if len(exit_ids):
        after=(t>=t[j]-1e-7)&(t<=t[j]+A['after_stairs_window_s']+1e-7)
        full=bool(t[-1]>=t[j]+A['after_stairs_window_s']-1e-7)
        result.update(after_window_available=full,after_max_error_deg=float(abs(error[after]).max()),
                      after_mean_error_deg=float(error[after].mean()),
                      before_to_after_mean_delta_deg=float(error[after].mean()-error[before].mean()) if before.any() else None,
                      exit_error_deg=float(error[j]),
                      heading_pass=bool(full and inside and not fell and before.any()
                          and abs(error[before]).max()<=A['heading_limit_deg']
                          and abs(error[after]).max()<=A['heading_limit_deg']))
    return result


def self_test():
    t=np.arange(0,20.001,.02);p=np.zeros((len(t),3));v=np.zeros((len(t),6));yaw=np.zeros(len(t))
    stationary=window_stats(t,p,yaw,v,0)
    assert stationary['max_displacement_m']==0 and stationary['settling_time_s']==0
    oscillating=p.copy();oscillating[:,0]=.2*np.sin(2*np.pi*t/20)
    excursion=window_stats(t,oscillating,yaw,v,0)
    assert excursion['net_displacement_m']<1e-10 and excursion['max_displacement_m']>.19
    v[t<1,3]=.1;v[t>=1,3]=.001
    assert abs(settled_time(t,v,0)-1)<1e-6
    wheels=np.zeros((len(t),4,3));wheels[:,:,0]=np.linspace(-1,8,len(t))[:,None]
    p[:,0]=wheels[:,0,0]
    section={'name':'fixture','start_x':1.,'end_x':4.}
    good_yaw=np.where(p[:,0]>=4.1,4.,0.);bad_yaw=np.where(p[:,0]>=4.1,8.,0.)
    good=section_stats(t,p,wheels,good_yaw,section,0,False)
    bad=section_stats(t,p,wheels,bad_yaw,section,0,False)
    assert good['heading_pass'] and not bad['heading_pass']
    assert not section_stats(t,p,wheels,good_yaw,section,0,True)['heading_pass']
    bypass=wheels.copy();bypass[:,:,1]=3.
    assert not section_stats(t,p,bypass,good_yaw,section,0,False)['heading_pass']
    incomplete=section_stats(t[:300],p[:300],wheels[:300],yaw[:300],section,0,False)
    assert not incomplete['completed'] and not incomplete['heading_pass']
    quaternion=np.column_stack((np.cos(np.deg2rad(yaw)/2),np.zeros((len(t),2)),np.sin(np.deg2rad(yaw)/2)))
    assert np.allclose(angles(quaternion)[:,2],yaw)
    return {'known_stationary_pass':True,'net_zero_oscillation_rejected':True,
            'known_settling_time':True,'4degree_pass_8degree_rejected':True,
            'fall_bypass_incomplete_rejected':True,'quaternion_yaw_roundtrip':True}


def calculate(label,case):
    folder=OUT/f'{label}_{case}';receipt=json.loads((folder/'receipt.json').read_text())
    assert receipt['checkpoint']==SPEC['checkpoints'][label]
    assert receipt['source_sha256']==SPEC['source_sha256']
    assert receipt['deterministic_actor'] and not receipt['course_correction']
    assert receipt['command_schedule']==SPEC['cases'][case]['command_schedule']
    assert receipt['live_capture']
    with np.load(folder/'state.npz') as f: state={k:f[k].copy() for k in f.files}
    with np.load(folder/'control.npz') as f: control={k:f[k].copy() for k in f.files}
    with np.load(folder/'control_quiet.npz') as f: quiet={k:f[k].copy() for k in f.files}
    metadata=json.loads(str(quiet['metadata']))
    assert metadata['checkpoint']==SPEC['checkpoints'][label]['frozen_copy']
    assert metadata['model']==SPEC['robot_xml']
    assert metadata['terrain_xml']==SPEC['terrain_xml'][SPEC['cases'][case]['terrain']]
    t,p,e=state['time'],state['position'],angles(state['quaternion'])
    assert len(t)==receipt['result']['steps_executed']==len(control['time'])
    assert receipt['mj_step1_calls']==receipt['mj_step2_calls']==4*len(t)
    assert np.allclose(t-control['time'],.02,atol=1e-8)
    assert np.allclose(np.diff(t),.02) and np.allclose(np.diff(quiet['time']),.005)
    expected=np.zeros_like(control['command'])
    for switch, command in SPEC['cases'][case]['command_schedule']:
        expected[control['time']>=switch]=command
    assert np.array_equal(expected,control['command'])
    assert (control['mode'][control['time']>=6.06]=='policy').all()
    assert control['action'].shape[1]==16 and state['policy_observation'].shape[1]==244
    assert all(np.isfinite(state[k]).all() for k in state)
    assert np.allclose(quiet['specific_energy'],.5*quiet['speed']**2,atol=1e-6)
    assert np.allclose(quiet['force_norm_N'],np.linalg.norm(quiet['force'],axis=-1))
    result={'fell':receipt['result']['fell_in_policy'],'duration_s':float(t[-1]),
            'full_duration':len(t)==round(SPEC['cases'][case]['duration_s']/.02),
            'frames':receipt['frames'],'peak_RSS_MiB':receipt['peak_RSS_MiB'],
            'wall_seconds':receipt['wall_seconds'],'compiled_model_sha256':receipt['compiled_model_sha256'],
            'trajectory_checks_passed':True,'video':'/'+str((folder/'live.mp4').relative_to(Path('/')))}
    policy=control['mode']=='policy'
    result['max_roll_abs_deg']=float(abs(e[policy,0]).max());result['max_pitch_abs_deg']=float(abs(e[policy,1]).max())
    if case in {'idle','move_stop'}:
        start=10. if case=='idle' else A['stop_reference_time_s']
        result.update(window_stats(t,p,e[:,2],state['world_velocity'],start))
        result['final_wheel_actions']=control['action'][-1,12:].tolist()
        result['final_wheel_target_rad_s']=(control['action'][-1,12:]*5.).tolist()
        threshold=A['max_stationary_displacement_m'] if case=='idle' else A['max_stop_displacement_m']
        result['static_stop_constraints_pass']=bool(result.get('window_available') and not result['fell'] and result['full_duration']
            and result['max_displacement_m']<=threshold
            and result['last10_path_speed_m_s']<=A['max_last10_path_speed_m_s']
            and result['max_yaw_excursion_deg']<=A['max_stationary_or_stop_yaw_deg'])
        if case=='move_stop':
            before=np.flatnonzero(t>=8.02-1e-7)[0];stop=np.flatnonzero(t>=A['stop_reference_time_s']-1e-7)[0]
            result['prestop_forward_progress_m']=float(p[stop,0]-p[before,0])
    else:
        moving=np.flatnonzero(np.linalg.norm(control['command'][:,:2],axis=1)>.1)[0]
        result['sections']=[section_stats(t,p,state['wheels_world'],e[:,2],section,float(t[moving]),result['fell'])
                            for section in SPEC['cases'][case]['sections']]
        result['all_stairs_heading_pass']=all(v['heading_pass'] for v in result['sections'])
        mask=(quiet['time']>=8)&(quiet['root_pos_w'][:,0]>=SPEC['cases'][case]['sections'][0]['start_x'])
        mask &= quiet['root_pos_w'][:,0]<SPEC['cases'][case]['sections'][-1]['end_x']
        events=[(int(i),int(w)) for i,w in np.argwhere(quiet['event']&mask[:,None])
                if i+8<=len(mask) and mask[i:i+8].all()]
        completed=all(v['completed'] and v['inside_course_during'] for v in result['sections']) and not result['fell']
        result['landing_performance_eligible']=completed
        result['touchdown_events_in_stairs']=len(events)
        if events:
            result['touchdown_40ms_mean_peak_force_N']=float(np.mean([quiet['force_norm_N'][i:i+8,w].max() for i,w in events]))
            result['touchdown_mean_pre_speed_m_s']=float(np.mean([quiet['speed'][i,w] for i,w in events]))
            result['touchdown_mean_specific_energy_J_kg']=float(np.mean([quiet['specific_energy'][i,w] for i,w in events]))
            span=float(np.ptp(quiet['root_pos_w'][mask,0]));result['touchdown_cumulative_specific_energy_per_forward_m']=float(sum(quiet['specific_energy'][i,w] for i,w in events)/span)
    return result


def main():
    checks=self_test();metrics={label:{} for label in ['v1','cpu','v2']}
    partial='--partial' in sys.argv
    for label in metrics:
        for case in SPEC['cases']:
            folder=OUT/f'{label}_{case}'
            if not (folder/'receipt.json').is_file():
                if partial: continue
                raise RuntimeError(f'Missing actual run: {label}/{case}')
            metrics[label][case]=calculate(label,case)
    for case in SPEC['cases']:
        hashes=[metrics[label][case]['compiled_model_sha256'] for label in metrics if case in metrics[label]]
        assert len(set(hashes))<=1,f'Physics models differ between policies: {case}'
    if all('move_stop' in metrics[label] for label in metrics):
        base=metrics['v1']['move_stop']['prestop_forward_progress_m']
        assert base>0
        threshold=json.loads((OUT/'motion_criteria_addendum.json').read_text())['prestop_forward_progress_min_fraction_of_v1']
        for label in metrics:
            v=metrics[label]['move_stop'];v['movement_preservation_fraction']=v['prestop_forward_progress_m']/base
            v['movement_preserved']=v['movement_preservation_fraction']>=threshold
            v['stop_acceptance_pass']=v['static_stop_constraints_pass'] and v['movement_preserved']
    for case in ['combined','ascent','descent']:
        if not all(case in metrics[label] for label in metrics): continue
        base=metrics['v1'][case]
        for label in metrics:
            candidate=metrics[label][case]
            if not (base['landing_performance_eligible'] and candidate['landing_performance_eligible']): continue
            for field in ['touchdown_40ms_mean_peak_force_N','touchdown_cumulative_specific_energy_per_forward_m']:
                if base.get(field) is not None and candidate.get(field) is not None:
                    candidate[field+'_ratio_vs_v1']=candidate[field]/base[field]
    result={'spec':str(OUT/'criteria.json'),'instrument_self_tests':checks,'models':SPEC['checkpoints'],
            'metrics':metrics,'cases_completed':sum(len(v) for v in metrics.values()),
            'limits':['one deterministic run per fixed scenario, not statistical generalization',
                      'no real hardware testing','landing means from falling/incomplete cases are not a full traversal result']}
    (OUT/('metrics_partial.json' if partial else 'metrics.json')).write_text(json.dumps(result,ensure_ascii=False,indent=2,allow_nan=False))
    print('ANALYSIS_COMPLETED',result['cases_completed'],'cases; instrument positive/negative checks pass')
    for label,values in metrics.items():
        for case,v in values.items():
            if case in {'idle','move_stop'}:
                print(label,case,'drift_cm',v.get('max_displacement_m',float('nan'))*100,
                      'last10_mm_s',v.get('last10_path_speed_m_s',float('nan'))*1000,
                      'yaw_deg',v.get('max_yaw_excursion_deg'),'settle',v.get('settling_time_s'))
            else:
                print(label,case,'fell',v['fell'],'sections',[(s['name'],s['completed'],s['before_max_error_deg'],s['after_max_error_deg'],s['during_max_error_deg'],s['heading_pass']) for s in v['sections']])


if __name__=='__main__': main()
