"""Prepare a fresh output folder for the archived, fixed MuJoCo comparison."""
from pathlib import Path
import argparse
import hashlib
import json
import shutil

p=argparse.ArgumentParser()
p.add_argument('--output',type=Path,required=True,help='A new folder that does not exist')
args=p.parse_args()
work=Path(__file__).resolve().parent
spec=json.loads((work/'spec.json').read_text())
assert not args.output.exists(),'Choose a new output folder; existing data will not be overwritten'
for filename,expected in spec['source_sha256'].items():
    assert hashlib.sha256(Path(filename).read_bytes()).hexdigest()==expected,filename
for label,identity in spec['checkpoints'].items():
    frozen=work/f'{label}.pt'
    assert hashlib.sha256(frozen.read_bytes()).hexdigest()==identity['sha256'],label
    identity['original_checkpoint_path']=identity['path']
    identity['path']=str(frozen)
    identity['frozen_copy']=str(frozen)
available_kib=int(next(v for v in Path('/proc/meminfo').read_text().splitlines() if v.startswith('MemAvailable:')).split()[1])
assert available_kib*1024>2*1024**3,'Need at least 2 GiB available RAM for serial CPU evaluation'
assert shutil.disk_usage(args.output.parent).free>1024**3,'Need at least 1 GiB free disk'
spec['work']=str(work)
spec['output']=str(args.output.resolve())
(work/'as_used_spec.json').write_text((work/'spec.json').read_text())
args.output.mkdir()
(work/'spec.json').write_text(json.dumps(spec,ensure_ascii=False,indent=2))
(args.output/'criteria.json').write_text((work/'spec.json').read_text())
shutil.copyfile(work/'motion_criteria_addendum.json',args.output/'motion_criteria_addendum.json')
(args.output/'criteria.json').chmod(0o444)
(args.output/'motion_criteria_addendum.json').chmod(0o444)
print('Prepared new output:',args.output)
print('CPU only, serial, no training. Keep the same external M20 assets and environment.')
